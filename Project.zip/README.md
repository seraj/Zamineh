# Zamineh React Web Application

clone Project 
`git clone https://github.com/seraj/Zamineh.git`

install Project Dependencies with NPM

`npm install`


then start it

`npm start`

for build Project

`npm run build`
