import React from 'react'


export const flickityOptions = {
    initialIndex: 0,
    pageDots: false,
    contain: true,
    rightToLeft: true,
    cellAlign: 'right',
    groupCells: true

    //   groupCells: true
};
export default flickityOptions
