import React from 'react';

const Error = () => (
    <div>
        <h1>چیزی یافت نشد</h1>
    </div>
);

export default Error;
