import axios from 'axios';
import cookie from 'react-cookies'
import Urls from '../components/Urls';

export default function SecurityManager() {

    return {

        checkForLogin: function () {
            return axios.post('https://test.com/', {
                client_id: cookie.load('auth_client_id', { path: '/' }),
                client_secret: cookie.load('auth_client_secret', { path: '/' }),
                grant_type: 'refresh_token'
            }).then((response) => {

                cookie.save('access_token', response.data.access_token, { path: '/' });
                cookie.save('token_type', response.data.token_type, { path: '/' });

                return true
            })
                .catch(function (error) {
                    // cookie.save('access_token', null, { path: '/' });
                    return false
                });
        },
        isLogined() {
            var auth_token = cookie.load('access_token', { path: '/' });
            if (auth_token && auth_token != 'null') {

                return true
            } else {
                return false
            }
        },

        refreshToken: function () {
            return axios.post(`${Urls().api()}/o/auth-token/`, {

                client_id: cookie.load('auth_client_id', { path: '/' }),
                client_secret: cookie.load('auth_client_secret', { path: '/' }),
                refresh_token: cookie.load('refresh_token', { path: '/' }),
                grant_type: 'refresh_token'
            }
            )
        },

        getAuthToken() {
            return cookie.load('access_token', { path: '/' });
        },
        setAccessToken(token) {
            return cookie.save('access_token', token, { path: '/' });
        },
        setRefreshToken(token) {
            return cookie.save('refresh_token', token, { path: '/' });
        },


        RemoveClientIDSecret() {
            cookie.remove('client_id');
            cookie.remove('client_secret')
        },
        RemoveAuthClientIDSecret() {
            cookie.remove('auth_client_id');
            cookie.remove('auth_client_secret')
        },
        logout() {
            cookie.save('access_token', null, { path: '/' });
            cookie.remove('access_token');
            cookie.remove('token_type')
            cookie.remove('refresh_token')
            // axios.get('/accounts/logout/').then((response) => {
            //     if (!window.location.href.includes('/mag/'))
            //         window.location = '/'
            // })
            // .catch(function (error) { });
        },
        removeLoginedUser() {
            cookie.remove('access_token');
            cookie.remove('refresh_token')
        },











        //Gallery Registration Cookies

        getGalleryRegAuthToken() {
            return cookie.load('gallery_access_token', { path: Urls().GalleryProfile() });
        },
        setGalleryRegAccessToken(token) {
            return cookie.save('gallery_access_token', token, { path: Urls().GalleryProfile() });
        },
        setGalleryRegRefreshToken(token) {
            return cookie.save('gallery_refresh_token', token, { path: Urls().GalleryProfile() });
        },
        hasGalleryRegToken() {
            var gallery_access_token = cookie.load('gallery_access_token', { path: Urls().GalleryProfile() });
            if (gallery_access_token && gallery_access_token != 'null') {
                return true
            } else {
                return false
            }
        },
        setGalleryRegClientIDSecret(id, secret) {
            cookie.save('gallery_auth_client_id', id, { path: Urls().GalleryProfile() });
            cookie.save('gallery_auth_client_secret', secret, { path: Urls().GalleryProfile() });
        },
        refreshGalleryRegToken: function () {
            return axios.post(`${Urls().api()}/o/auth-token/`, {
                client_id: cookie.load('gallery_auth_client_id', { path: Urls().GalleryProfile() }),
                client_secret: cookie.load('gallery_auth_client_secret', { path: Urls().GalleryProfile() }),
                refresh_token: cookie.load('gallery_refresh_token', { path: Urls().GalleryProfile() }),
                grant_type: 'refresh_token'
            }
            )
        },
        GalleryRegLogout() {
            cookie.save('gallery_access_token', null, { path: Urls().GalleryProfile() });
            cookie.remove('gallery_access_token');
            cookie.remove('gallery_refresh_token')
        },





        //Artist Registration Cookies
        getArtistRegAuthToken() {
            return cookie.load('artist_access_token', { path: Urls().ArtistProfile() });
        },
        setArtistRegAccessToken(token) {
            return cookie.save('artist_access_token', token, { path: Urls().ArtistProfile() });
        },
        setArtistRegRefreshToken(token) {
            return cookie.save('artist_refresh_token', token, { path: Urls().ArtistProfile() });
        },
        hasArtistRegToken() {
            var artist_access_token = cookie.load('artist_access_token', { path: Urls().ArtistProfile() });
            if (artist_access_token && artist_access_token != 'null') {
                return true
            } else {
                return false
            }
        },
        refreshArtistRegToken: function () {
            return axios.post(`${Urls().api()}/o/auth-token/`, {
                client_id: cookie.load('artist_auth_client_id', { path: Urls().ArtistProfile() }),
                client_secret: cookie.load('artist_auth_client_secret', { path: Urls().ArtistProfile() }),
                refresh_token: cookie.load('artist_refresh_token', { path: Urls().ArtistProfile() }),
                grant_type: 'refresh_token'
            }
            )
        },
        setArtistRegClientIDSecret(id, secret) {
            cookie.save('artist_auth_client_id', id, { path: Urls().ArtistProfile() });
            cookie.save('artist_auth_client_secret', secret, { path: Urls().ArtistProfile() });
        },
        ArtistRegLogout() {
            cookie.save('artist_access_token', null, { path: Urls().ArtistProfile() });
            cookie.remove('artist_access_token');
            cookie.remove('artist_refresh_token')
        },


        getRegClientIDSecret(type, page) {

            if (type == 'secret') {
                if (page == 'Gallery') {
                    return cookie.load('gallery_auth_client_secret', { path: Urls().GalleryProfile() })
                } else if (page == 'Artist') {
                    return cookie.load('artist_auth_client_secret', { path: Urls().ArtistProfile() })
                }
            }
            if (type == 'id') {
                if (page == 'Gallery') {
                    return cookie.load('gallery_auth_client_id', { path: Urls().GalleryProfile() })
                } else if (page == 'Artist') {
                    return cookie.load('artist_auth_client_id', { path: Urls().ArtistProfile() })
                }
            }
        },

        // Jury Panel
        setJuryPanelClientIDSecret(id, secret) {
            cookie.save('jury_auth_client_id', id, { path: Urls().JuryPanel() });
            cookie.save('jury_auth_client_secret', secret, { path: Urls().JuryPanel() });
        },

    }
}
